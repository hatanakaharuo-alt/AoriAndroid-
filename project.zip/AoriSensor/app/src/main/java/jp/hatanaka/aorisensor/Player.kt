package jp.hatanaka.aorisensor

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * 曲の再生。アラーム用の音声経路で鳴らすので、マナーモードでも鳴る
 * （音量は端末の「アラームの音量」×アプリの音量設定）。
 */
object Player {
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { BleHub.stopAlarm() }

    var playing by mutableStateOf(false)
        private set

    /** 内蔵の音：ヒットはアラーム音、切断は通知音 */
    fun builtIn(forHit: Boolean): Uri? {
        val type = if (forHit) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION
        return RingtoneManager.getDefaultUri(type)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
    }

    fun play(ctx: Context, song: String?, forHit: Boolean, loop: Boolean, durationSec: Int, volume: Int) {
        stop()
        val uri = song?.let { Uri.parse(it) } ?: builtIn(forHit) ?: return
        val p = MediaPlayer()
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setDataSource(ctx, uri)
            p.isLooping = loop
            val v = (volume / 100f).let { it * it }
            p.setVolume(v, v)
            p.setOnCompletionListener { if (!it.isLooping) stop() }
            p.prepare()
            p.start()
            mp = p
            playing = true
            if (durationSec > 0) handler.postDelayed(autoStop, durationSec * 1000L)
        } catch (e: Exception) {
            try { p.release() } catch (_: Exception) {}
            // 曲ファイルが読めない（削除された等）ときは内蔵の音で鳴らす
            if (song != null) play(ctx, null, forHit, loop, durationSec, volume)
        }
    }

    fun setVolume(volume: Int) {
        val v = (volume / 100f).let { it * it }
        try { mp?.setVolume(v, v) } catch (_: Exception) {}
    }

    fun stop() {
        handler.removeCallbacks(autoStop)
        mp?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        mp = null
        playing = false
    }
}
