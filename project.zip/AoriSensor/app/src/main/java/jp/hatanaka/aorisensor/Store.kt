package jp.hatanaka.aorisensor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** 曲ライブラリの1曲（端末内の音楽ファイルのURIと表示名） */
data class Song(val uri: String, val name: String)

/** 一度接続したことのあるセンサー（Bluetoothアドレスで識別） */
data class Known(val addr: String, val name: String)

/** アプリの設定。端末内に保存し、次回起動時に復元する */
class Settings {
    var volume = 80          // 0〜100
    var loop = true          // 止めるまで繰り返す
    var duration = 0         // 自動で止めるまでの秒数（0=止めない）
    var cooldown = 3         // 連続ヒットを無視する秒数
    var warn = true          // 接続が切れたら音で知らせる
    var warnSong: String? = null  // 切断時の曲（null=内蔵の通知音）
    var prefix = "iFish, iTAG, iTag"
    val known = mutableListOf<Known>()
    val names = mutableMapOf<String, String>()   // アドレス -> 竿の呼び名
    val assign = mutableMapOf<String, String>()  // アドレス -> 曲のURI
    val lib = mutableListOf<Song>()

    fun prefixes(): List<String> =
        prefix.split(Regex("[,、\\s]+")).map { it.trim() }.filter { it.isNotEmpty() }
}

object Store {
    private const val PREF = "aori"
    private const val KEY = "settings"

    fun load(ctx: Context): Settings {
        val s = Settings()
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return s
        try {
            val o = JSONObject(raw)
            s.volume = o.optInt("volume", s.volume)
            s.loop = o.optBoolean("loop", s.loop)
            s.duration = o.optInt("duration", s.duration)
            s.cooldown = o.optInt("cooldown", s.cooldown)
            s.warn = o.optBoolean("warn", s.warn)
            s.warnSong = if (o.has("warnSong") && !o.isNull("warnSong")) o.getString("warnSong") else null
            s.prefix = o.optString("prefix", s.prefix)
            o.optJSONArray("known")?.let { a ->
                for (i in 0 until a.length()) {
                    val k = a.getJSONObject(i)
                    s.known.add(Known(k.getString("addr"), k.optString("name")))
                }
            }
            o.optJSONObject("names")?.let { m -> m.keys().forEach { s.names[it] = m.getString(it) } }
            o.optJSONObject("assign")?.let { m -> m.keys().forEach { s.assign[it] = m.getString(it) } }
            o.optJSONArray("lib")?.let { a ->
                for (i in 0 until a.length()) {
                    val k = a.getJSONObject(i)
                    s.lib.add(Song(k.getString("uri"), k.optString("name")))
                }
            }
        } catch (_: Exception) {
        }
        return s
    }

    fun save(ctx: Context, s: Settings) {
        val o = JSONObject()
        o.put("volume", s.volume)
        o.put("loop", s.loop)
        o.put("duration", s.duration)
        o.put("cooldown", s.cooldown)
        o.put("warn", s.warn)
        o.put("warnSong", s.warnSong ?: JSONObject.NULL)
        o.put("prefix", s.prefix)
        o.put("known", JSONArray().apply {
            s.known.forEach { put(JSONObject().put("addr", it.addr).put("name", it.name)) }
        })
        o.put("names", JSONObject().apply { s.names.forEach { (k, v) -> put(k, v) } })
        o.put("assign", JSONObject().apply { s.assign.forEach { (k, v) -> put(k, v) } })
        o.put("lib", JSONArray().apply {
            s.lib.forEach { put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        })
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }
}
