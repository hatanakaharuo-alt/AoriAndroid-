package jp.hatanaka.aorisensor

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** 接続中（または再接続待ち）のセンサー */
class Sensor(val addr: String, name: String) {
    var name by mutableStateOf(name)
    /** connecting / connected / lost */
    var state by mutableStateOf("connecting")
    var gatt: BluetoothGatt? = null
    var everConnected = false
    var connectedAt = 0L
    var lastHit = 0L
    var hitEntry: String? = null
    var ifishCount: Int? = null
    var manual = false
    val pending = ArrayDeque<Pair<BluetoothGattDescriptor, ByteArray>>()
}

/** 画面全体に出す知らせ（ヒット／接続切れ） */
data class Alert(val kind: String, val label: String, val time: String, val addr: String)

/** スキャンで見つかった機器 */
data class Found(val addr: String, val name: String, val rssi: Int)

@SuppressLint("MissingPermission")
object BleHub {
    private const val WARMUP_MS = 5000L       // 接続直後はヒット判定しない
    private const val POWER_OFF_MS = 6000L    // ヒット直後の切断は長押しでの電源OFFとみなす
    private val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    lateinit var app: Context
        private set
    lateinit var settings: Settings
        private set
    private var inited = false
    val main = Handler(Looper.getMainLooper())

    val sensors = mutableStateListOf<Sensor>()
    val hitLog = mutableStateListOf<String>()
    val rxLog = mutableStateListOf<String>()
    val found = mutableStateListOf<Found>()
    var rev by mutableIntStateOf(0)        // 設定が変わったら増やして画面を更新
    var hitCount by mutableIntStateOf(0)
    var alert by mutableStateOf<Alert?>(null)
    var lastRx by mutableStateOf("")
    var scanning by mutableStateOf(false)
    private var lastHitAddr: String? = null

    fun init(ctx: Context) {
        if (inited) return
        app = ctx.applicationContext
        settings = Store.load(app)
        inited = true
    }

    fun save() { Store.save(app, settings); rev++ }

    private fun adapter(): BluetoothAdapter? =
        (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    fun bluetoothOn(): Boolean = adapter()?.isEnabled == true

    private fun now() = System.currentTimeMillis()
    private fun hhmmss() = SimpleDateFormat("HH:mm:ss", Locale.JAPAN).format(Date())
    private fun toast(msg: String) = Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()

    // ---------- 竿の名前・曲 ----------
    fun knownIndex(addr: String) = settings.known.indexOfFirst { it.addr == addr }
    fun label(addr: String): String =
        settings.names[addr] ?: "竿${(knownIndex(addr).takeIf { it >= 0 } ?: settings.known.size) + 1}"

    fun dispName(addr: String): String {
        val k = settings.known.find { it.addr == addr }
        val n = k?.name ?: sensors.find { it.addr == addr }?.name ?: addr
        val same = settings.known.count { it.name == n }
        return if (same > 1) n + "・" + addr.replace(":", "").takeLast(4) else n
    }

    fun songFor(addr: String): Song? = settings.assign[addr]?.let { u -> settings.lib.find { it.uri == u } }
    fun warnSong(): Song? = settings.warnSong?.let { u -> settings.lib.find { it.uri == u } }

    fun rename(addr: String, nick: String) {
        if (nick.isBlank()) settings.names.remove(addr) else settings.names[addr] = nick.trim()
        save(); SensorService.refresh(app)
    }

    fun assign(addr: String, uri: String?) {
        if (uri == null) settings.assign.remove(addr) else settings.assign[addr] = uri
        save()
    }

    fun setWarnSong(uri: String?) { settings.warnSong = uri; save() }

    fun addSong(uri: String, name: String) {
        if (settings.lib.none { it.uri == uri }) settings.lib.add(Song(uri, name))
        save()
    }

    fun removeSong(uri: String) {
        settings.lib.removeAll { it.uri == uri }
        settings.assign.entries.removeAll { it.value == uri }
        if (settings.warnSong == uri) settings.warnSong = null
        save()
    }

    fun forget(addr: String) {
        sensors.find { it.addr == addr }?.let { disconnect(it) }
        settings.known.removeAll { it.addr == addr }
        settings.names.remove(addr)
        settings.assign.remove(addr)
        save()
    }

    private fun remember(addr: String, name: String) {
        val i = knownIndex(addr)
        if (i < 0) settings.known.add(Known(addr, name))
        else if (settings.known[i].name != name && name.isNotBlank()) settings.known[i] = Known(addr, name)
        save()
    }

    // ---------- スキャン ----------
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = r.scanRecord?.deviceName ?: r.device.name ?: return
            val pf = settings.prefixes()
            if (pf.isNotEmpty() && pf.none { name.startsWith(it) }) return
            val f = Found(r.device.address, name, r.rssi)
            main.post {
                val i = found.indexOfFirst { it.addr == f.addr }
                if (i >= 0) found[i] = f else found.add(f)
            }
        }
    }
    private val stopScanRunnable = Runnable { stopScan() }

    fun startScan() {
        val sc = adapter()?.bluetoothLeScanner ?: run { toast("Bluetoothをオンにしてください"); return }
        stopScan()
        found.clear()
        try {
            sc.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCb)
            scanning = true
            main.postDelayed(stopScanRunnable, 20000)
        } catch (e: Exception) {
            toast("スキャンできません：${e.message}")
        }
    }

    fun stopScan() {
        main.removeCallbacks(stopScanRunnable)
        if (scanning) {
            try { adapter()?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
        }
        scanning = false
    }

    // ---------- 接続 ----------
    fun connect(addr: String, name: String) {
        val ad = adapter() ?: return
        if (!ad.isEnabled) { toast("Bluetoothをオンにしてください"); return }
        var s = sensors.find { it.addr == addr }
        if (s == null) {
            s = Sensor(addr, name)
            sensors.add(s)
        } else if (s.state == "connected") return
        remember(addr, name)
        s.manual = false
        s.state = "connecting"
        SensorService.start(app)
        openGatt(s, auto = false)
    }

    private fun openGatt(s: Sensor, auto: Boolean) {
        try { s.gatt?.close() } catch (_: Exception) {}
        s.gatt = null
        val dev: BluetoothDevice = try { adapter()?.getRemoteDevice(s.addr) } catch (_: Exception) { null } ?: return
        // auto=true：センサーが電波の届く所に戻ったら、OSが自動でつなぎ直す
        s.gatt = dev.connectGatt(app, auto, callbackFor(s), BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect(s: Sensor) {
        s.manual = true
        try { s.gatt?.disconnect() } catch (_: Exception) {}
        try { s.gatt?.close() } catch (_: Exception) {}
        s.gatt = null
        sensors.remove(s)
        if (alert?.addr == s.addr) stopAlarm()
        if (sensors.isEmpty()) SensorService.stop(app) else SensorService.refresh(app)
    }

    fun disconnectAll() { sensors.toList().forEach { disconnect(it) } }

    private fun callbackFor(s: Sensor) = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                if (s.gatt !== g) return@post
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    onDisconnected(s)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            main.post { if (s.gatt === g) subscribeAll(s, g) }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            main.post { if (s.gatt === g) nextDescriptor(s, g) }
        }

        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT >= 33) return
            val v = c.value ?: return
            val copy = v.copyOf()
            val u = c.uuid
            main.post { onValue(s, u, copy) }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            val u = c.uuid
            val copy = value.copyOf()
            main.post { onValue(s, u, copy) }
        }
    }

    /** 通知できる特性をすべて受信する設定にする（1つずつ順番に書き込む） */
    private fun subscribeAll(s: Sensor, g: BluetoothGatt) {
        s.pending.clear()
        for (svc in g.services) for (c in svc.characteristics) {
            val p = c.properties
            val notify = (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
            val indicate = (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
            if (!notify && !indicate) continue
            g.setCharacteristicNotification(c, true)
            val d = c.getDescriptor(CCCD) ?: continue
            val v = if (notify) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            s.pending.addLast(Pair(d, v))
        }
        nextDescriptor(s, g)
        // 書き込みの応答が来ない機種でも先へ進めるよう、一定時間で接続完了とみなす
        main.postDelayed({ if (s.gatt === g && s.state != "connected") ready(s) }, 6000)
    }

    @Suppress("DEPRECATION")
    private fun nextDescriptor(s: Sensor, g: BluetoothGatt) {
        val item = s.pending.removeFirstOrNull() ?: run { if (s.state != "connected") ready(s); return }
        val (d, v) = item
        val ok = if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, v) == android.bluetooth.BluetoothStatusCodes.SUCCESS
        } else {
            d.value = v
            g.writeDescriptor(d)
        }
        if (!ok) main.postDelayed({ if (s.gatt === g) nextDescriptor(s, g) }, 100)
    }

    /** 接続完了（ヒット待ち） */
    private fun ready(s: Sensor) {
        s.state = "connected"
        s.everConnected = true
        s.connectedAt = now()
        s.ifishCount = null
        addRx("${label(s.addr)} ── 接続しました（5秒間はヒット判定しません）")
        // 接続切れの曲が鳴っている最中に、その竿（または切れていた全ての竿）が戻ったら止める
        val a = alert
        if (a != null && a.kind == "lost") {
            val stillLost = sensors.any { it !== s && it.state != "connected" }
            if (a.addr == s.addr || !stillLost) {
                stopAlarm()
                toast("${label(s.addr)}に再接続しました")
            }
        }
        SensorService.refresh(app)
    }

    private fun shortUuid(u: UUID): String {
        val t = u.toString().lowercase()
        return if (t.startsWith("0000") && t.endsWith("-0000-1000-8000-00805f9b34fb")) t.substring(4, 8) else t
    }

    private fun addRx(line: String) {
        rxLog.add(0, "${hhmmss()}  $line")
        while (rxLog.size > 100) rxLog.removeAt(rxLog.size - 1)
    }

    private fun onValue(s: Sensor, uuid: UUID, v: ByteArray) {
        val u = shortUuid(uuid)
        val hex = v.joinToString(" ") { "%02x".format(it.toInt() and 0xff) }
        addRx("${label(s.addr)} $u：$hex")
        lastRx = "最新の受信 ${hhmmss()}  ${label(s.addr)} $u：$hex"
        if (s.state != "connected" || now() - s.connectedAt < WARMUP_MS) {
            if (u == "fff1" && v.size >= 2) s.ifishCount = v[1].toInt() and 0xff
            return
        }
        // iTAG：ボタン（接点）が押されるたびにFFE1へ通知が届く
        if (u == "ffe1") { hit(s); return }
        // iFish：FFF1に「01 [ヒット回数] 01」が届く。回数が変わったときだけヒット
        if (u == "fff1" && v.size >= 2) {
            val n = v[1].toInt() and 0xff
            if (n == s.ifishCount) return
            s.ifishCount = n
            hit(s)
        }
    }

    private fun hit(s: Sensor) {
        val t = now()
        if (t - s.lastHit < settings.cooldown * 1000L) return
        s.lastHit = t
        hitCount++
        val entry = "${hhmmss()}  ${label(s.addr)} ヒット"
        hitLog.add(0, entry)
        s.hitEntry = entry
        lastHitAddr = s.addr
        alert = Alert("hit", label(s.addr), hhmmss(), s.addr)
        Player.play(app, songFor(s.addr)?.uri, true, settings.loop, settings.duration, settings.volume)
        SensorService.showAlert(app, "Hit !!!  ${label(s.addr)}")
    }

    private fun onDisconnected(s: Sensor) {
        try { s.gatt?.close() } catch (_: Exception) {}
        s.gatt = null
        if (s.manual) return
        val wasConnected = s.state == "connected"
        s.state = "lost"
        if (wasConnected) addRx("${label(s.addr)} ── 接続が切れました")
        // iTAGはボタン長押しで電源が切れる。押した瞬間の信号でヒットになった直後に切れたら、
        // ヒットではなく電源OFFとみなしてヒットを取り消す
        val powerOff = s.lastHit > 0 && now() - s.lastHit < POWER_OFF_MS && lastHitAddr == s.addr
        if (powerOff) {
            hitCount = maxOf(0, hitCount - 1)
            s.hitEntry?.let { hitLog.remove(it) }
            s.lastHit = 0
            lastHitAddr = null
        }
        // OSに自動再接続を任せる（センサーの電源が入る／電波が届くと自動でつながる）
        main.postDelayed({ if (!s.manual && sensors.contains(s)) openGatt(s, auto = true) }, 1000)
        SensorService.refresh(app)
        if (!s.everConnected) return
        if (!settings.warn) return
        val a = alert
        if (!powerOff && a != null && a.kind == "hit") { toast("${label(s.addr)}の接続が切れました"); return }
        toast(if (powerOff) "${label(s.addr)}の電源が切れました" else "${label(s.addr)}の接続が切れました")
        alert = Alert("lost", label(s.addr), hhmmss(), s.addr)
        Player.play(app, warnSong()?.uri, false, settings.loop, settings.duration, settings.volume)
        SensorService.showAlert(app, "接続切れ  ${label(s.addr)}")
    }

    fun stopAlarm() {
        Player.stop()
        alert = null
        SensorService.clearAlert(app)
    }

    fun clearLogs() { hitLog.clear(); rxLog.clear(); hitCount = 0 }
}
