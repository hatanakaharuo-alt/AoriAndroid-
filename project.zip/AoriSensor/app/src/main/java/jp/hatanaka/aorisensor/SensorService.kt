package jp.hatanaka.aorisensor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * 画面オフ・他のアプリ使用中でもセンサーとの接続と曲の再生を続けるためのサービス。
 * 起動中は通知欄に「待機中」と表示される。
 */
class SensorService : Service() {
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        BleHub.init(applicationContext)
        running = true
        createChannels(this)
        val n = statusNotification(this)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(ID_STATUS, n)
            }
        } catch (e: Exception) {
            // Bluetoothの許可がない等で開始できないときは、アプリ自体は落とさずにサービスだけ止める
            running = false
            stopSelf()
            return
        }
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aori:sensor").apply {
                setReferenceCounted(false)
                acquire()
            }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> BleHub.stopAlarm()
            ACTION_QUIT -> { BleHub.disconnectAll(); stopSelf() }
            else -> nm(this).notify(ID_STATUS, statusNotification(this))
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CH_STATUS = "status"
        private const val CH_ALERT = "alert"
        private const val ID_STATUS = 1
        private const val ID_ALERT = 2
        const val ACTION_STOP_ALARM = "stop_alarm"
        const val ACTION_QUIT = "quit"
        private var running = false

        private fun nm(ctx: Context) = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        fun start(ctx: Context) {
            running = true
            ContextCompat.startForegroundService(ctx, Intent(ctx, SensorService::class.java))
        }

        fun stop(ctx: Context) {
            running = false
            ctx.stopService(Intent(ctx, SensorService::class.java))
        }

        /** 通知欄の「待機中（n台）」を更新 */
        fun refresh(ctx: Context) {
            if (!running) return
            try { nm(ctx).notify(ID_STATUS, statusNotification(ctx)) } catch (_: Exception) {}
        }

        private fun createChannels(ctx: Context) {
            val m = nm(ctx)
            m.createNotificationChannel(
                NotificationChannel(CH_STATUS, "待機中の表示", NotificationManager.IMPORTANCE_LOW)
            )
            m.createNotificationChannel(
                NotificationChannel(CH_ALERT, "ヒット・接続切れ", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(null, null) // 音はアプリが曲で鳴らす
                    enableVibration(true)
                }
            )
        }

        private fun openApp(ctx: Context, req: Int): PendingIntent =
            PendingIntent.getActivity(
                ctx, req,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun service(ctx: Context, action: String, req: Int): PendingIntent =
            PendingIntent.getService(
                ctx, req, Intent(ctx, SensorService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun statusNotification(ctx: Context): Notification {
            val ok = BleHub.sensors.count { it.state == "connected" }
            val lost = BleHub.sensors.size - ok
            val text = if (lost > 0) "待機中（$ok 台）・$lost 台が再接続待ち" else "待機中（$ok 台）"
            return NotificationCompat.Builder(ctx, CH_STATUS)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("アオリイカセンサー")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(openApp(ctx, 10))
                .addAction(0, "終了", service(ctx, ACTION_QUIT, 11))
                .build()
        }

        /** ヒット・接続切れの通知。画面オフ・ロック中でもアプリの画面を前面に出す */
        fun showAlert(ctx: Context, title: String) {
            if (!running) return
            val n = NotificationCompat.Builder(ctx, CH_ALERT)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle(title)
                .setContentText("タップで画面を開く")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(openApp(ctx, 20))
                .setFullScreenIntent(openApp(ctx, 21), true)
                .addAction(0, "音を止める", service(ctx, ACTION_STOP_ALARM, 22))
                .setAutoCancel(true)
                .build()
            try { nm(ctx).notify(ID_ALERT, n) } catch (_: Exception) {}
        }

        fun clearAlert(ctx: Context) {
            try { nm(ctx).cancel(ID_ALERT) } catch (_: Exception) {}
        }
    }
}
