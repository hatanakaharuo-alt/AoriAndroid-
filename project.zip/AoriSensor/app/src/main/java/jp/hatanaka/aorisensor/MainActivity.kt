package jp.hatanaka.aorisensor

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings as AndroidSettings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private object C {
    val bg = Color(0xFFE6F0EE)
    val surface = Color(0xFFFFFFFF)
    val ink = Color(0xFF12313A)
    val muted = Color(0xFF58737E)
    val line = Color(0xFFC7D9D6)
    val float = Color(0xFFF2641A)
    val ok = Color(0xFF1C8A6E)
    val danger = Color(0xFFC3302A)
    val hit = Color(0xFFE3121B)
}

class MainActivity : ComponentActivity() {
    private var onSongPicked: ((String) -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { askBluetoothOn() }

    private val btOnLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> if (uri != null) songPicked(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ヒットの通知から開いたとき、ロック中でも画面を表示して点灯する
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        BleHub.init(applicationContext)
        requestPermissions()
        setContent { App(this) }
    }

    override fun onResume() {
        super.onResume()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.takeIf { BleHub.alert != null } ?: 0)
    }

    private fun requestPermissions() {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            list += Manifest.permission.BLUETOOTH_SCAN
            list += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            list += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(list.toTypedArray())
    }

    @SuppressLint("MissingPermission")
    fun askBluetoothOn() {
        if (!BleHub.bluetoothOn()) {
            try { btOnLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
        }
    }

    fun pickSong(then: (String) -> Unit) {
        onSongPicked = then
        pickAudio.launch(arrayOf("audio/*"))
    }

    private fun songPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        var name = uri.lastPathSegment ?: "曲"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: name
            }
        } catch (_: Exception) {
        }
        BleHub.addSong(uri.toString(), name)
        onSongPicked?.invoke(uri.toString())
        onSongPicked = null
    }

    fun openBatterySettings() {
        try { startActivity(Intent(AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {}
    }
}

// ================= 画面 =================

/** 曲選択ダイアログの対象（竿のアドレス、または切断時の音） */
private data class SongTarget(val addr: String?, val title: String)

@Composable
fun App(act: MainActivity) {
    @Suppress("UNUSED_VARIABLE") val rev = BleHub.rev
    var showScan by remember { mutableStateOf(false) }
    var songTarget by remember { mutableStateOf<SongTarget?>(null) }
    var renameAddr by remember { mutableStateOf<String?>(null) }
    var showRx by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(primary = C.float, background = C.bg, surface = C.surface)) {
        Box(Modifier.fillMaxSize().background(C.bg)) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                item {
                    Text("アオリイカセンサー", fontSize = 30.sp, fontWeight = FontWeight.Black, color = C.ink)
                    Text("Android版 v2", fontSize = 12.sp, color = C.muted)
                }
                item { School() }
                item { StatusBlock(onAdd = { act.askBluetoothOn(); showScan = true; BleHub.startScan() }) }
                items(BleHub.settings.known.toList(), key = { it.addr }) { k ->
                    SensorRow(k, onRename = { renameAddr = k.addr },
                        onSong = { songTarget = SongTarget(k.addr, "${BleHub.label(k.addr)}の曲を選ぶ") })
                }
                item { SoundSettings(act, onWarnSong = { songTarget = SongTarget(null, "接続が切れたときの音を選ぶ") }) }
                item { Logs(showRx, onToggleRx = { showRx = !showRx }) }
            }

            BleHub.alert?.let { AlertOverlay(it) }

            if (showScan) ScanDialog(onClose = { BleHub.stopScan(); showScan = false })
            songTarget?.let { t -> SongDialog(act, t, onClose = { songTarget = null }) }
            renameAddr?.let { a -> RenameDialog(a, onClose = { renameAddr = null }) }
        }
    }
}

@Composable
private fun Pill(text: String, filled: Boolean = false, color: Color = C.ink, onClick: () -> Unit) {
    if (filled) {
        Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = C.float, contentColor = Color.White),
            shape = RoundedCornerShape(50), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)) {
            Text(text, fontWeight = FontWeight.Bold)
        }
    } else {
        OutlinedButton(onClick = onClick, shape = RoundedCornerShape(50),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = color)) {
            Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

private val grayMatrix = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })

/** センサーの数だけアジを泳がせる（接続中は色付きで泳ぎ、切断中はグレー） */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun School() {
    val list = BleHub.sensors.toList()
    val n = maxOf(1, list.size)
    val w = when { n == 1 -> 240; n == 2 -> 160; n <= 4 -> 135; n <= 6 -> 105; else -> 85 }
    val tr = rememberInfiniteTransition(label = "bob")
    val phase by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart), label = "p")
    Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
        FlowRow(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            for (i in 0 until n) {
                val s = list.getOrNull(i)
                val on = s?.state == "connected"
                val t = ((phase + i * 0.22f) % 1f) * 2f * Math.PI.toFloat()
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(4.dp)) {
                    Image(
                        painterResource(R.drawable.fish), contentDescription = null,
                        colorFilter = if (on) null else grayMatrix,
                        modifier = Modifier.width(w.dp)
                            .alpha(if (on) 1f else 0.45f)
                            .graphicsLayer {
                                if (on) {
                                    translationX = -6f * kotlin.math.sin(t)
                                    translationY = 5f * kotlin.math.sin(t)
                                    rotationZ = -2f * kotlin.math.sin(t)
                                }
                            }
                    )
                    if (s != null && n > 1) Text(BleHub.label(s.addr), fontSize = 12.sp, color = C.muted)
                }
            }
        }
    }
}

@Composable
private fun StatusBlock(onAdd: () -> Unit) {
    val list = BleHub.sensors.toList()
    val ok = list.count { it.state == "connected" }
    val trouble = list.size - ok
    val (title, color, sub) = when {
        list.isEmpty() -> Triple("未接続", C.ink, "センサーの電源を入れて「センサーに接続」を押してください")
        ok == 0 -> Triple("接続が切れました", C.danger, "${trouble}台が再接続待ちです")
        trouble > 0 -> Triple("待機中（${ok}台）", C.ok, "${trouble}台の接続が切れています")
        else -> Triple("待機中（${ok}台）", C.ok, "画面を消しても待機を続けます")
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = color)
        Text(sub, fontSize = 14.sp, color = C.muted, textAlign = TextAlign.Center)
        if (BleHub.lastRx.isNotEmpty()) Text(BleHub.lastRx, fontSize = 12.sp, color = C.muted)
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onAdd, modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(containerColor = C.float, contentColor = Color.White)
        ) { Text(if (list.isEmpty()) "センサーに接続" else "センサーを追加", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        if (list.size >= 2) {
            Spacer(Modifier.height(6.dp))
            Pill("すべて切断") { BleHub.disconnectAll() }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SensorRow(k: Known, onRename: () -> Unit, onSong: () -> Unit) {
    val s = BleHub.sensors.find { it.addr == k.addr }
    val stateText = when (s?.state) {
        null -> "未接続"; "connected" -> "待機中"; "connecting" -> "接続中…"; else -> "再接続待ち"
    }
    val dot = when (s?.state) { null -> C.line; "connected" -> C.ok; else -> C.danger }
    val song = BleHub.songFor(k.addr)
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(BleHub.label(k.addr), fontWeight = FontWeight.Bold, color = C.ink, fontSize = 17.sp)
                Text("${BleHub.dispName(k.addr)}　$stateText", fontSize = 12.sp, color = C.muted,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Pill("名前", onClick = onRename)
            Spacer(Modifier.width(4.dp))
            Pill("曲", onClick = onSong)
            Spacer(Modifier.width(4.dp))
            if (s != null) Pill("切断") { BleHub.disconnect(s) }
            else Pill("接続") { BleHub.connect(k.addr, k.name) }
        }
        Row(Modifier.padding(start = 20.dp, top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("曲：${song?.name ?: "内蔵アラーム"}", fontSize = 13.sp, color = C.muted,
                modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = {
                if (Player.playing) BleHub.stopAlarm()
                else Player.play(BleHub.app, song?.uri, true, false, 0, BleHub.settings.volume)
            }) { Text(if (Player.playing) "止める" else "試しに鳴らす", color = C.float) }
            if (s == null) TextButton(onClick = { BleHub.forget(k.addr) }) { Text("削除", color = C.danger) }
        }
        HorizontalDivider(color = C.line)
    }
}

@Composable
private fun NumberRow(label: String, value: Int, max: Int, onChange: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f), color = C.ink)
        OutlinedTextField(
            value = text,
            onValueChange = { t ->
                text = t.filter { it.isDigit() }.take(3)
                text.toIntOrNull()?.let { onChange(it.coerceIn(0, max)) }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.width(90.dp)
        )
    }
}

@Composable
private fun SoundSettings(act: MainActivity, onWarnSong: () -> Unit) {
    val st = BleHub.settings
    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Text("音の設定", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.ink)
        Text("曲は竿ごとに、一覧の「曲」から選びます。選んでいない竿は内蔵アラームが鳴ります。アラームの音声経路で鳴らすので、マナーモードでも鳴ります（端末の「アラームの音量」も確認してください）。",
            fontSize = 13.sp, color = C.muted)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("音量", Modifier.weight(1f), color = C.ink)
            Text("${st.volume}", fontWeight = FontWeight.Bold, color = C.ink)
        }
        Slider(
            value = st.volume.toFloat(), valueRange = 0f..100f,
            onValueChange = { st.volume = it.toInt(); Player.setVolume(st.volume); BleHub.rev++ },
            onValueChangeFinished = { BleHub.save() },
            colors = SliderDefaults.colors(thumbColor = C.float, activeTrackColor = C.float)
        )
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("止めるまで繰り返す", Modifier.weight(1f), color = C.ink)
            Switch(checked = st.loop, onCheckedChange = { st.loop = it; BleHub.save() },
                colors = SwitchDefaults.colors(checkedTrackColor = C.float))
        }
        NumberRow("自動で止めるまでの秒数（0で止めない）", st.duration, 600) { st.duration = it; BleHub.save() }
        NumberRow("連続ヒットを無視する秒数", st.cooldown, 120) { st.cooldown = it; BleHub.save() }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("接続が切れたら音で知らせる", Modifier.weight(1f), color = C.ink)
            Switch(checked = st.warn, onCheckedChange = { st.warn = it; BleHub.save() },
                colors = SwitchDefaults.colors(checkedTrackColor = C.float))
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("切断時の音：${BleHub.warnSong()?.name ?: "内蔵の通知音"}", Modifier.weight(1f), color = C.ink,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Pill("曲", onClick = onWarnSong)
            Spacer(Modifier.width(4.dp))
            Pill(if (Player.playing) "止める" else "試す") {
                if (Player.playing) BleHub.stopAlarm()
                else Player.play(BleHub.app, BleHub.warnSong()?.uri, false, false, 0, st.volume)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("センサー名の先頭（カンマ区切り・大文字小文字を区別）", fontSize = 13.sp, color = C.muted)
        var pf by remember { mutableStateOf(st.prefix) }
        OutlinedTextField(value = pf, onValueChange = { pf = it; st.prefix = it; BleHub.save() },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("画面を消している間に待機が止まる場合は、このアプリの電池の最適化をオフにしてください。",
            fontSize = 13.sp, color = C.muted)
        Pill("電池の最適化の設定を開く") { act.openBatterySettings() }
    }
}

@Composable
private fun Logs(showRx: Boolean, onToggleRx: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 40.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("今日のヒット", Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.ink)
            Text("${BleHub.hitCount}", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = C.ink)
        }
        BleHub.hitLog.toList().take(50).forEach { Text(it, color = C.muted, fontSize = 14.sp) }
        TextButton(onClick = onToggleRx) { Text(if (showRx) "▼ 受信データの記録" else "▶ 受信データの記録", color = C.ink) }
        if (showRx) BleHub.rxLog.toList().forEach { Text(it, color = C.muted, fontSize = 12.sp) }
        Pill("記録を消す") { BleHub.clearLogs() }
    }
}

/** ヒット／接続切れの全画面表示 */
@Composable
private fun AlertOverlay(a: Alert) {
    val tr = rememberInfiniteTransition(label = "alert")
    val blink by tr.animateFloat(1f, 0.25f, infiniteRepeatable(tween(350), RepeatMode.Reverse), label = "blink")
    val wiggle by tr.animateFloat(-5f, 4f, infiniteRepeatable(tween(450), RepeatMode.Reverse), label = "wiggle")
    val pounce = remember(a) { Animatable(0.4f) }
    LaunchedEffect(a) { pounce.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMediumLow)) }
    Box(
        Modifier.fillMaxSize().background(C.bg).clickable { BleHub.stopAlarm() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (a.kind == "hit") "Hit !!!" else "接続切れ", color = C.hit, fontSize = 60.sp,
                fontWeight = FontWeight.Black, modifier = Modifier.alpha(blink))
            if (a.kind == "hit") {
                Image(
                    painterResource(R.drawable.squid), contentDescription = null,
                    modifier = Modifier.height(300.dp).graphicsLayer {
                        scaleX = pounce.value; scaleY = pounce.value
                        rotationZ = wiggle
                        translationX = (1f - pounce.value) * 300f
                        translationY = -(1f - pounce.value) * 300f
                    }
                )
            }
            Text(a.label, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = C.ink)
            Text(a.time, fontSize = 18.sp, color = C.ink)
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { BleHub.stopAlarm() }, shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = C.float, contentColor = Color.White),
                contentPadding = PaddingValues(horizontal = 48.dp, vertical = 16.dp)
            ) { Text("音を止める", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }
        }
    }
}

@Composable
private fun ScanDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("センサーを選ぶ") },
        text = {
            Column {
                Text(if (BleHub.scanning) "探しています…（センサーの電源を入れてください）" else "検索を終了しました",
                    fontSize = 13.sp, color = C.muted)
                Spacer(Modifier.height(8.dp))
                val connected = BleHub.sensors.map { it.addr }.toSet()
                BleHub.found.toList().filter { it.addr !in connected }.sortedByDescending { it.rssi }.forEach { f ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .border(1.dp, C.line, RoundedCornerShape(12.dp))
                            .clickable { BleHub.connect(f.addr, f.name); onClose() }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, fontWeight = FontWeight.Bold)
                            Text(f.addr, fontSize = 12.sp, color = C.muted)
                        }
                        Text("${f.rssi} dBm", fontSize = 12.sp, color = C.muted)
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        },
        confirmButton = {
            if (!BleHub.scanning) TextButton(onClick = { BleHub.startScan() }) { Text("もう一度探す") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("閉じる") } }
    )
}

@Composable
private fun SongDialog(act: MainActivity, t: SongTarget, onClose: () -> Unit) {
    val current = if (t.addr != null) BleHub.songFor(t.addr)?.uri else BleHub.warnSong()?.uri
    val pick: (String?) -> Unit = { uri ->
        if (t.addr != null) BleHub.assign(t.addr, uri) else BleHub.setWarnSong(uri)
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(t.title) },
        text = {
            Column {
                val items = listOf<Song?>(null) + BleHub.settings.lib.toList()
                items.forEach { song ->
                    val selected = song?.uri == current
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .border(if (selected) 2.dp else 1.dp, if (selected) C.float else C.line, RoundedCornerShape(12.dp))
                            .clickable { pick(song?.uri); onClose() }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(song?.name ?: (if (t.addr != null) "内蔵アラーム" else "内蔵の通知音"),
                            Modifier.weight(1f), fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (song != null) TextButton(onClick = { BleHub.removeSong(song.uri) }) {
                            Text("削除", color = C.danger, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { act.pickSong { uri -> pick(uri) }; onClose() }) { Text("ファイルから追加") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("閉じる") } }
    )
}

@Composable
private fun RenameDialog(addr: String, onClose: () -> Unit) {
    var text by remember { mutableStateOf(BleHub.settings.names[addr] ?: "") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("この竿の名前") },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true,
                placeholder = { Text("例：右の竿（空欄で竿番号）") })
        },
        confirmButton = { TextButton(onClick = { BleHub.rename(addr, text); onClose() }) { Text("保存") } },
        dismissButton = { TextButton(onClick = onClose) { Text("キャンセル") } }
    )
}
